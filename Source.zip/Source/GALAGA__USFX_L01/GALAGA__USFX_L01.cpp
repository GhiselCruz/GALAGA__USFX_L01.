// Copyright Epic Games, Inc. All Rights Reserved.

#include "GALAGA__USFX_L01.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GALAGA__USFX_L01, "GALAGA__USFX_L01" );

DEFINE_LOG_CATEGORY(LogGALAGA__USFX_L01)
 